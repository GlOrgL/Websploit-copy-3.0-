#!/usr/bin/env python
#
#Websploit FrameWork Upgrade Module
# Created By 0x0ptim0us (Fardin Allahverdinazhand)
# Email : 0x0ptim0us@Gmail.Com

import os
import urllib
from time import sleep
from core import wcolors
import webbrowser

def upgrade():
    print(wcolors.color.BLUE + "[*] Internal update/upgrade system is disabled on Debian systems. See /usr/share/doc/websploit/README.Debian for more info" + wcolors.color.ENDC)
    pass
