WebSploit Framework

Project in SourceForge : http://sourceforge.net/projects/websploit

Author : 0x0ptim0us (Fardin Allahverdinazhand)
Email & Report Bug : 0x0ptim0us@Gmail.Com
Blog : http://0x0ptim0us.blogspot.com

If your system doesn't have enough copies of the full text of the GNU
General Public License already, we have provided another one in the
"COPYING.GPL" file. 

Supported Attack :
#	[+]Autopwn - Used From Metasploit For Scan and Exploit Target Service
#	[+]Browser AutoPWN - Exploit Victim Browser
#	[+]wmap - Scan,Crawler Target Used From Metasploit wmap plugin
#	[+]format infector - inject reverse & bind payload into file format
#	[+]MLITM,XSS Phishing - Man Left In The Middle Attack
#	[+]MITM - Man In The Middle Attack
#	[+]USB Infection Attack - Create Executable Backdoor For Windows
#	[+]MFOD Attack - Middle Finger Of Doom Attack
#	[+]Java Applet Attack Vector 
#	[+]ARP DOS - ARP Cache Denial Of Service Attack With Random MAC
#	[+]Directory Scanner - Scan Target Directorys
#	[+]Apache US - Scan Apache users
#	[+]PHPMyAdmin - Scan PHPMyAdmin Login Page
#	[+]Web Killer - Using From The TCPKill For Down Your WebSite On Network
#	[+]Fake AP - Fake Access Point
#	[+]FakeUpdate - Fake update attack 
#   [+]Wifi Jammer - Wifi Jammer Attack
#   [+]Wifi Dos - Wifi Dos RQ Attack
#   [+]Wifi Mass De-authentication attack