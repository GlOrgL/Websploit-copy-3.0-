#!/usr/bin/env python
#
# WebSploit FrameWork Update Module
# Created By 0x0ptim0us (Fardin Allahverdinazhand)
# Email : 0x0ptim0us@Gmail.Com

import os
import subprocess
from core import wcolors
from time import sleep

def update():
    print(wcolors.color.BLUE + "[*] Internal update/upgrade system is disabled on Debian systems. See /usr/share/doc/websploit/README.Debian for more info" + wcolors.color.ENDC)
    pass
