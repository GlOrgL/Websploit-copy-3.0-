#!/usr/bin/env python
#
# WebSploit FrameWork Update Module
# Created By 0x0ptim0us (Fardin Allahverdinazhand)
# Email : 0x0ptim0us@Gmail.Com

import os
import subprocess
from core import wcolors
from time import sleep

def update():
    print(wcolors.color.BLUE + "[*] Use wsf-update.py script for update, you can find this script in installation folder [/usr/share/websploit]" + wcolors.color.ENDC)
    pass
